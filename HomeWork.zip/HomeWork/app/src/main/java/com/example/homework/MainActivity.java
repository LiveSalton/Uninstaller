package com.example.homework;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.StatFs;
import android.text.format.Formatter;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.homework.adapter.MyAdapter;
import com.example.homework.entity.AppInfo;
import com.example.homework.util.Utils;

import java.io.File;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;


public class MainActivity extends Activity
        implements AdapterView.OnItemClickListener, IUninstall, SearchView.OnQueryTextListener, AdapterView.OnItemLongClickListener {

    List<AppInfo> list;// 数据
    List<AppInfo> allList = new ArrayList<AppInfo>();
    ListView lv; // 列表视图
    TextView tv1, tv2, tv3, tv4;
    ImageView img;
    MyAdapter adapter; // 适配器

    public static final int SORT_NAME = 0;//按名称排序
    public static final int SORT_DATE = 1;//按日期排序
    public static final int SORT_SIZE = 2;//按大小排序

    final String[] sorts = {"名称", "日期", "大小"};

    int currSort = SORT_DATE;//当前排序
    Comparator<AppInfo> comparator = null;// 当前所使用的比较器

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Utils.KEY = "";//初始化
        // 初始化控件
        lv = (ListView) findViewById(R.id.lv_main);
        adapter = new MyAdapter(this);
        adapter.setList(list);
        adapter.setUninstall(this);// 传入接口
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(this);
        lv.setOnItemLongClickListener(this);
        sort = (TextView) findViewById(R.id.sort);
        count = (TextView) findViewById(R.id.count);
        size = (TextView) findViewById(R.id.size);
        iv_asc = (ImageView) findViewById(R.id.iv_asc);
        tv1 = (TextView) findViewById(R.id.sd1);
        tv2 = (TextView) findViewById(R.id.sd2);
        tv3 = (TextView) findViewById(R.id.sd3);
        tv4 = (TextView) findViewById(R.id.sd4);
        img = (ImageView) findViewById(R.id.img3);
        donghua();
        updateData();// 子线程--拿数据
    }

    //声明变量3
    SearchView sv;
    MenuItem search;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        search = menu.findItem(R.id.search);//容器
        sv = (SearchView) search.getActionView();//真正的搜索对象
        sv.setIconifiedByDefault(false);//图标显示在外侧
        sv.setSubmitButtonEnabled(true);//让提交按钮可用
        sv.setQueryHint("请输入应用名");//提示用户信息
        sv.setOnQueryTextListener(this);//关联提交事件
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();


        if (id == R.id.sort_name) {
            currSort = SORT_NAME;// 给排序状态赋值
        } else if (id == R.id.sort_date) {
            currSort = SORT_DATE;
        } else if (id == R.id.sort_size) {
            currSort = SORT_SIZE;
        }


        update_sort();// 调用统一的排序方法

        asc *= -1;//负数,正数

        return super.onOptionsItemSelected(item);
    }

    // 带排序的更新
    private void update_sort() {
        if (currSort == SORT_NAME) {
            comparator = nameComparator;// 选择不同的比较器
        }
        if (currSort == SORT_DATE) {
            comparator = dateComparator;
        }
        if (currSort == SORT_SIZE) {
            comparator = sizeComparator;
        }
        Collections.sort(list, comparator);// 这里才是排序的操作
        adapter.setList(list);
        adapter.notifyDataSetChanged();// 刷新视图
        update_infobar();
    }

    int asc = 1; // 可以帮助在正序和倒序之间进行切换
    // 日期比较器
    Comparator<AppInfo> dateComparator = new Comparator<AppInfo>() {
        @Override
        public int compare(AppInfo lhs, AppInfo rhs) {


            if (rhs.lastUpdateTime > lhs.lastUpdateTime
                    ) {
                return -1 * asc;
            } else if (rhs.lastUpdateTime == lhs.lastUpdateTime) {
                return 0;
            } else {
                return 1 * asc;
            }
        }
    };

    // 大小比较器
    Comparator<AppInfo> sizeComparator = new Comparator<AppInfo>() {
        @Override
        public int compare(AppInfo lhs, AppInfo rhs) {
            if (rhs.byteSize > lhs.byteSize) {
                return -1 * asc;
            } else if (rhs.byteSize == lhs.byteSize) {
                return 0;
            } else {
                return 1 * asc;
            }
        }
    };

    // 应用名比较器
    Comparator<AppInfo> nameComparator = new Comparator<AppInfo>() {
        @Override
        public int compare(AppInfo lhs, AppInfo rhs) {
            // 为了适应汉字的比较
            Collator c = Collator.getInstance(Locale.CHINA);
            return (asc == 1) ? c.compare(lhs.appName, rhs.appName)
                    : c.compare(rhs.appName, lhs.appName);
        }
    };


    // 1声明进度框对象
    ProgressDialog pd;

    // 显示一个环形进度框
    public void showProgressDialog() {
        // 实例化
        pd = new ProgressDialog(this);
        // "旋转"风格
        pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        pd.setTitle("系统信息");
        pd.setMessage("正在加载应用列表,请耐心等待...");
        pd.show();// 显示
    }

    Handler handler = new Handler() {// 内部类

        @Override
        public void handleMessage(Message msg) {
            // 重写方法
            if (msg.what == 1) {// UI 线程的回调处理
                pd.dismiss();
                // 更新列表
                adapter.notifyDataSetChanged();
                size();

                Log.i("spl", "----------------------" + list.size());
                Toast.makeText(MainActivity.this
                        , "应用数:" + list.size(), Toast.LENGTH_LONG).show();
                update_sort();
            }
        }
    };

    //3.子线程
    private void updateData() {

        // (1)--启动新线程,处理耗时操作
        new Thread() {
            public void run() {
                // 获得数据(所有的应用)
                list = Utils.getAppList(MainActivity.this);
                allList.clear();// 清空
                allList.addAll(list);// 复制集合
                adapter.setList(list);
                // 给主线程发消息

                Message msg = handler.obtainMessage();
                msg.what = 1;
                handler.sendMessage(msg);// msg.what=1
            }

            ;
        }.start();
        // (2) --
        showProgressDialog();// 显示进度框
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        // 获取本行的应用信息对象
        AppInfo app = (AppInfo) parent.getItemAtPosition(position);
        // 运行应用
        Utils.openPackage(this, app.packageName);
    }

    @Override
    public void onBtnClick(int pos, String packageName) {
        Utils.uninstallApk(this, packageName, 0);//0-requestCode
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // 接收窗体返回值
        if (requestCode == 0) {
            // 刷新列表
            updateData();
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    ImageView iv_asc;
    TextView sort, count, size;

    // 更新顶部信息栏中内容
    private void update_infobar() {


        if (asc == 1) {
            iv_asc.setImageResource(android.R.drawable.arrow_up_float);
        } else {
            iv_asc.setImageResource(android.R.drawable.arrow_down_float);
        }


        sort.setText("排序: " + sorts[currSort]);

        //sort.setOnClickListener(this);
        count.setText("应用数: " + list.size());
        size.setText("大小: " + getListSize());
    }

    /**
     * 遍历数据集合,累加全部的Size
     *
     * @return
     */
    private String getListSize() {
        long sum = 0;// 总和
        for (AppInfo app : list) {// foreach
            sum += app.byteSize;
        }
        return Utils.getSize2(sum);
    }

    public void clickImg(View v) {
        // (1)切换正序/倒序
        update_sort();
        asc *= -1;

    }

    long time = System.currentTimeMillis();

    @Override
    public void onBackPressed() {
        // 点击"回退"键

        // 计算和上次点击的时间差
        long delta = System.currentTimeMillis() - time;
        if (delta < 1000) {// 小于1秒
            // 用户真的要退出
            finish();
        } else {// 不让用户退出
            Toast.makeText(this, "再点击一次退出", Toast.LENGTH_SHORT).show();
            time = System.currentTimeMillis();// 让time更新为当前时间
        }
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        //提交关键字
        Utils.toast(this, "您查询的关键字是 ：" + query.trim());
        Utils.KEY = query.trim();
        list = Utils.getSearchResult(allList, query);//根据关键字生成结果
        update_sort();//重新排序事件

        return true;//消化事件
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        //结果集越搜越小
        //我们永远保持一个最初结果集
        // Utils.toast(this, "您查询的是:" + newText.trim());
        Utils.KEY = newText.trim();
        list = Utils.getSearchResult(allList, newText.trim());//根就关键字生成结果
        update_sort();//重新排序更新

        return true;
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        AppInfo app = (AppInfo) parent.getItemAtPosition(position);
        Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
        String pkg = "com.android.settings";
        String cls = "com.android.settings.applications.InstalledAppDetails";
        intent.setComponent(new ComponentName(pkg, cls));
        intent.setData(Uri.parse("package:" + app.packageName));//指明要打开的应用
        startActivity(intent);// 用普通的方法去打开界面
        return true;// 消化掉事件
    }

    public void size() {
        tv1.setText("SD卡总大小：" + getSDTotalSize());
        tv2.setText("SD卡剩余大小：" + getSDAvailableSize());
        tv3.setText("内存总大小：" + getRomTotalSize());
        tv4.setText("内存剩余大小：" + getRomAvailableSize());
    }

    /**
     * 获得SD卡总大小
     *
     * @return
     */
    private String getSDTotalSize() {
        File path = Environment.getExternalStorageDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSize();
        long totalBlocks = stat.getBlockCount();
        return Formatter.formatFileSize(MainActivity.this, blockSize * totalBlocks);
    }

    /**
     * 获得sd卡剩余容量，即可用大小
     *
     * @return
     */
    private String getSDAvailableSize() {
        File path = Environment.getExternalStorageDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSize();
        long availableBlocks = stat.getAvailableBlocks();
        return Formatter.formatFileSize(MainActivity.this, blockSize * availableBlocks);
    }

    /**
     * 获得机身内存总大小
     *
     * @return
     */
    private String getRomTotalSize() {
        File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSize();
        long totalBlocks = stat.getBlockCount();
        return Formatter.formatFileSize(MainActivity.this, blockSize * totalBlocks);
    }

    /**
     * 获得机身可用内存
     *
     * @return
     */
    private String getRomAvailableSize() {
        File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSize();
        long availableBlocks = stat.getAvailableBlocks();
        return Formatter.formatFileSize(MainActivity.this, blockSize * availableBlocks);
    }

    private String addZero(int n) {
        if (n < 10) {
            return "0" + n;
        } else {
            return "" + n;
        }
    }

    public void setFrameAnimation(ImageView iv,
                                  int start, int end,
                                  String preffix,
                                  Context context) {
        AnimationDrawable animationDrawable = new AnimationDrawable();//帧动画对象
        iv.setBackgroundDrawable(animationDrawable);//设置组件背景
        String packageName = context.getApplicationContext().getPackageName();//获取当前包名
        for (int i = start; i <= end; i++) {
            //从图片名称反射资源ID
            int id = context.getResources().getIdentifier(preffix + addZero(i), "drawable", packageName);
            Drawable frame = context.getResources().getDrawable(id);//得到动画帧的对象
            animationDrawable.addFrame(frame, 80);//添加帧,设定时间间隔
        }
        animationDrawable.setOneShot(false);// 只运行一次,false-无限循环
        animationDrawable.start();// 开始播放
    }

    public void donghua() {

        setFrameAnimation(img, 1, 27, "l10", this);

    }
}


